﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Task_Manager.Controllers
{
    using Pages;
    [ApiController]
    [Route("[action]")]
    public class TaskControllers : ControllerBase
    {
        public string Hello()
        {
            return "Hello";

        }
        [Route("{id:int}/{newDescription}")]

        public string ChangeDescriptionById(int id, string newDescription)
        {
            var task = IndexModel.tasks.FirstOrDefault(t => t.Id == id);
            task.Description = newDescription;

            return "success";

        }
        [Route("{id:int}")]

        public string SearchTaskById(int id)
        {
            var task = IndexModel.tasks.FirstOrDefault(t => t.Id == id);
           

            return task.Id.ToString() + task.Description+task.DueDate + task.IsCompleted+ task.CompletionDate;

        }
        [Route("{id:int}")]

        public string MarkCompleted(int id)
        {
            var task = IndexModel.tasks.FirstOrDefault(t => t.Id == id);
            task.IsCompleted = true;

            return "success";

        }

        public string GetAllTasks()
        {

            string final = "";
            for(int i=1; i<=IndexModel.tasks.Count; i++)
            {
                var task = IndexModel.tasks.FirstOrDefault(t => t.Id == i);


                string task_string =  "Task "+ i+ "- "+ task.Id.ToString() + task.Description + task.DueDate + task.IsCompleted + task.CompletionDate;

                final += task_string;

            }

            return final;

        }

        public string GetCompletedTasks()
        {

            string final = "";
            for (int i = 1; i <= IndexModel.tasks.Count; i++)
            {
                var task = IndexModel.tasks.FirstOrDefault(t => t.Id == i);

                if (task.IsCompleted == true)
                {
                    string task_string = "Task " + i + "- " + task.Id.ToString() + task.Description + task.DueDate + task.IsCompleted + task.CompletionDate;
                    final += task_string;
                }
                  
            }

            return final;

        }




    }

}
