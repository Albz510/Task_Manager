﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.Reflection;

namespace Task_Manager.Pages
{
    public class IndexModel : PageModel
    {
        //Dummy tasks
        public static List<TaskItem> tasks = new List<TaskItem>
        {
            new TaskItem { Id = 1, Description = "Buy friend birthday card", DueDate = new DateTime(2024,05,010,00,00,00) },
            new TaskItem { Id = 2, Description = "Take dog for walk", DueDate = DateTime.Now.AddDays(1) },
            new TaskItem { Id = 3, Description = "Throw friend birthday party", DueDate = new DateTime(2024,05,010,00,00,00) }
        };

        public List<TaskItem> Tasks => tasks;

        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public IActionResult OnPostRemoveTask(int taskId)
        {
            var taskToRemove = tasks.FirstOrDefault(t => t.Id == taskId);
            if (taskToRemove != null)
            {
                tasks.Remove(taskToRemove);
            }
            return RedirectToPage();
        }
        public IActionResult OnPostMarkCompleted(int taskId)
        {
            var taskToComplete = tasks.FirstOrDefault(t => t.Id == taskId);
            if (taskToComplete != null)
            {
                taskToComplete.IsCompleted = true;
                taskToComplete.CompletionDate = DateTime.Now;
            }
            return RedirectToPage();
        }
        public IActionResult OnPostAddTask(TaskItem addTask)
        {
            addTask.Id = tasks.Count + 1;
            Tasks.Add(addTask);
            return RedirectToPage();
        }

        public IActionResult OnPostUpdateTask(int id, string newDescription, DateTime newDueDate, bool newIsCompleted, DateTime? newCompletionDate)
        {
            var task = tasks.FirstOrDefault(t => t.Id == id);
            if (task == null)
                return NotFound();

            task.Description = newDescription;
            task.DueDate = newDueDate;
            task.IsCompleted = newIsCompleted;
            task.CompletionDate = newCompletionDate;

            return RedirectToPage();
        }




        public class TaskItem
        {
            public int Id { get; set; }
            public string Description { get; set; }
            public DateTime DueDate { get; set; }
            public bool IsCompleted { get; set; }
            public DateTime? CompletionDate { get; set; }

        };

    }
}

